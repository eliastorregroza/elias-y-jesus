lista1 = [4, 6, 8]
lista2 = [2, 1, 5]

lista_concatenada = lista1 + lista2
print("concatenacion:", lista_concatenada)

lista_repetida = lista1 * 3
print("repeticion:", lista_repetida)