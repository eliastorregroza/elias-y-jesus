A = 10 

print (A>5)
print (A<5)
print (A == 10)