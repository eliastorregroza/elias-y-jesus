A = 55
B = 99

S = A + B 
R = A - B
M = A * B
D = A / B 

print (S)
print (R)
print (M)
print (D)