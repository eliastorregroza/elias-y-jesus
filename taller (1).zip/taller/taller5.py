A = 5.7
B= 2.2

R1 = round(A)
R2 = round(B)

H = A**B

print(R1)
print(R2)
print(H)