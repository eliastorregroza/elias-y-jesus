cadena1 = "hola " 
cadena2 = "elias"

resultado = cadena1 + cadena2

print(resultado)
