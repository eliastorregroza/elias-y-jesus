a = True
b = False

reslutado_and = a and b
print("and", reslutado_and)

resultado_or = a or b
print("or;", resultado_or)

resultado_not_a = not a
resultado_not_b = not b
print("not a", resultado_not_a)
print("not b", resultado_not_b)

