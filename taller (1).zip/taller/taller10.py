entero = 10 
decimal = 3.8

suma = entero + decimal
print("suma: ",suma)

resta = entero - decimal
print("resta",resta)

mul= entero * decimal
print("multiplicar",mul)

div = entero / decimal
print("division",div)