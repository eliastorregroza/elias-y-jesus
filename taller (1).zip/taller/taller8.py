A = (1,2,3)
B = (4,5)

c = A + B
D = A * 2

print (c)
print (D)