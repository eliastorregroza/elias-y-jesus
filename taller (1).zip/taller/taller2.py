A = 10 
A += 2
print (A)

A -=2 

print(A)